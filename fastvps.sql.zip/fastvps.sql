-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июл 22 2013 г., 13:41
-- Версия сервера: 5.1.69
-- Версия PHP: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `fastvps`
--

-- --------------------------------------------------------

--
-- Структура таблицы `coins`
--

CREATE TABLE IF NOT EXISTS `coins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `keycode` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `nominal` int(11) NOT NULL,
  `value` decimal(6,4) NOT NULL,
  `updtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=68 ;

--
-- Дамп данных таблицы `coins`
--

INSERT INTO `coins` (`id`, `name`, `keycode`, `nominal`, `value`, `updtime`) VALUES
(3, 'Укр. гривна', 'UAH', 10, 39.7753, '2013-07-22 13:20:21'),
(4, 'Бел. рубль', 'BYR', 10000, 36.4369, '2013-07-22 13:26:25'),
(5, 'Доллар США', 'USD', 1, 32.4288, '2013-07-22 13:30:07'),
(6, 'Евро', 'EUR', 1, 42.5920, '2013-07-22 13:30:09'),
(43, 'Турецкая лира', 'TRY', 1, 16.8812, '2013-07-22 13:27:25'),
(52, 'Вон Корея', 'KRW', 1000, 28.8926, '2013-07-22 13:40:01');
